import java.util.Scanner;

public class LSFR {
	public static void main(String[] args) {
		System.out.println("请输入明文");
		Scanner in=new Scanner(System.in);
		String plaintext=in.nextLine();
		System.out.println("输入的明文长度为："+plaintext.length());
		int key[]=new int[plaintext.length()*7];
		key[0]=1;
		key[1]=1;
		key[2]=0;
		key[3]=0;
		key[4]=1;
		//进行异或操作，产生密钥
		for(int i=0;i<key.length-1;i++) {
			if(5+i<=key.length-1) //密钥不能超过数组
			{
			key[5+i]=key[3+i]^key[i];
			}
		}
		//输出密钥序列
		System.out.println("生成的密钥序列如下");
		for(int i=0;i<key.length;i++) {
			System.out.print(key[i]);
		}
		System.out.print("\n");
		//调用函数，进行加密
		myl(key,plaintext);		
	}
	public static void myl(int key[],String plaintext) {
		//用于从key中取七位数字进行存储
		int []shuzu=new int[plaintext.length()];
		//将明文输入，获得字节数字
		byte [] bytes=plaintext.getBytes();
		//flag用于计算这是从key中取的第几个值，要进行*7运算。
		int flag=0;
		//从key数组七位为一组进行读取，存到shuzu当中
		for(int i=0;i<bytes.length;i++) {
			for(int j=0;j<7;j++) {
				shuzu[i]=shuzu[i]*2;
				shuzu[i]+=key[j+flag*7];
			}
			flag++;
		}
		//cipertext用来存储异或的结果。
		char cipertext[]=new char[plaintext.length()];
		for(int i=0;i<plaintext.length();i++) {
			cipertext[i]=(char) (shuzu[i]^bytes[i]);
		}
		//对异或结果进行输出
		System.out.println("加密结果如下");
		for(int i=0;i<shuzu.length;i++) {
			System.out.print(cipertext[i]+" ");
		}
	}

}
