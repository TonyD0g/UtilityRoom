package JavaShell;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;

public class RSAPSS {
    public static int DBLength;
    public static byte[] H;
    public static BigInteger sigResult;
    public static byte[] EM;
    public static byte[] endH;
    public static byte[] M11;

    public static void main(String args[]) throws NoSuchAlgorithmException {
        //定义明文字符串M
        String M = "通知：今天下午3点开会！";
        //调用encode(M)方法得到明文M的消息编码
        EM = encode(M);
        BigInteger sigResult = sign(EM);
        System.out.println("A发送的数字签名:" + sigResult);

        if (verify(sigResult, M)) {
            System.out.printf("\n签名正确");
        } else {
            System.out.println("签名错误");
        }
    }

    public static boolean verify(BigInteger sig, String M) throws NoSuchAlgorithmException {
        System.out.println("B收到的数字签名:" + sig);
        RSA rsa = new RSA();
        MessageDigest mdTemp = MessageDigest.getInstance("SHA1");

        // 调用RSA.encode解密sig 得到EMtemp
        BigInteger EMtemp = rsa.encode(sig);

        byte[] bc = {(byte) 0xbc};

        byte[] getEndH = new byte[20];
        byte[] getMaskedDB = new byte[27];

        // 判断EM最后一位是否是0xbc
        if (EM[(EM.length - 1)] == bc[0]) {
            // 获取endH,其中maskDB长度为27,endH长度为10
            for (int i = 0; i < 20; i++) {
                getEndH[i] = EM[27 + i];
            }
            // 调用 MGF1类中的generateMask 求 mask
            MGF1 mgf1 = new MGF1(mdTemp);
            byte[] mask = mgf1.generateMask(getEndH, DBLength);

            // 获取 maskedDB
            for (int i = 0; i < 27; i++) {
                getMaskedDB[i] = EM[i];
            }
            byte[] DB = DB_Xor_Mask(getMaskedDB, mask);
            // 判断DB中倒数第21位是否是0x01
            if (DB[DB.length - 21] == 0x01) {
                // 若是，则从DB中获取salt,长度为20
                byte[] getSalt = new byte[20];
                int x = 0;
                for (int i = 7; i < DB.length; i++) {
                    getSalt[x] = DB[i];
                    x++;
                }

                // 计算明文的sha1值，得到H
                //得到 M1 = padding1 + H + salt ,长度为48
                byte[] padding1 = {0, 0, 0, 0, 0, 0, 0, 0};
                byte[] M1 = byteMerger(byteMerger(padding1, H), getSalt);

                // 计算M1 的sha1 值得到 endH2
                byte[] endH2 = getSha1(M1);
                int flag = 0;
                for (int i = 0; i < endH.length; i++) {
                    if (getEndH[i] != endH2[i]) {
                        flag = 1;
                        break;
                    }
                }
                System.out.println("A发送的M1 hash:");
                for (int i = 0; i < getEndH.length; i++) {
                    System.out.print(getEndH[i]);
                }

                System.out.println("\nB收到的M1 hash:");
                for (int i = 0; i < getEndH.length; i++) {
                    System.out.print(getEndH[i]);
                }

                if (flag == 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static byte[] toByteArray(BigInteger bi) {
        byte[] array = bi.toByteArray();
        // 这种情况是转换的array超过25位
        if (array[0] == 0) {
            byte[] tmp = new byte[array.length - 1];
            System.arraycopy(array, 1, tmp, 0, tmp.length);
            array = tmp;
        }
        // 假如转换的byte数组少于24位，则在前面补齐0
        if (array.length < 24) {
            byte[] tmp = new byte[24];
            System.arraycopy(array, 0, tmp, 24 - array.length, array.length);
            array = tmp;
        }
        return array;
    }

    public static BigInteger sign(byte[] EM) {
        // 将EM byte数组转化为 BigInteger 类型的m
        // 0xefd3e0f9618ff2e5aef9ebc814e1dc6b0d1707427ba52fb88fc94011f80864bd5aabad6b29ef39a07885dfa44b698fbc
        String s = "efd3e0f9618ff2e5aef9ebc814e1dc6b0d1707427ba52fb88fc94011f80864bd5aabad6b29ef39a07885dfa44b698fbc";
        // 最后一位为-68
        BigInteger m = new BigInteger(EM);

        // System.out.println("m:"+m);

        // 调用RSA.decrypt(m);得到签名结果sigResult
        RSA rsa = new RSA();
        sigResult = rsa.decode(m);

        return sigResult;
    }

    public static byte[] encode(String M) throws NoSuchAlgorithmException {
        MessageDigest mdTemp = MessageDigest.getInstance("SHA1");

        byte[] plaintext = M.getBytes(StandardCharsets.UTF_8);
        // 得到明文的sha1
        H = getSha1(plaintext);
//        System.out.println("H:");
//        for(int i=0;i<H.length;i++){
//            System.out.println(H[i]);
//        }
//        System.out.println();

        // 定义byte数组 padding1
        byte[] padding1 = {0, 0, 0, 0, 0, 0, 0, 0};
        // 生成随机byte数组 salt,这里我们写死
        byte[] salt = {(byte) 0xbc, (byte) 0x17, (byte) 0x9a, (byte) 0xa3, (byte) 0x47, (byte) 0x38, (byte) 0x9b, (byte) 0xf8, (byte) 0x74, (byte) 0x1f, (byte) 0xc5, (byte) 0xfe, (byte) 0xb6, (byte) 0x8d, (byte) 0x08, (byte) 0xfb, (byte) 0xcf, (byte) 0xcf, (byte) 0xa4, (byte) 0x9b};
//        System.out.println("salt:");
//        for(int i=0;i<salt.length;i++){
//            System.out.println(salt[i]);
//        }
//        System.out.println();

        // 将 padding1+H+salt存入byte数组 M1
        M11 = byteMerger(byteMerger(padding1, H), salt);

        // 定义 padding2,长度为1~10之间的随机数
        byte[] padding2 = {(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x01};
        // padding2+salt 存入DB数组
        byte[] DB = byteMerger(padding2, salt);
        // 获取M1的sha1值 endH
        endH = getSha1(M11);

        // 求掩码mask
        MGF1 mgf1 = new MGF1(mdTemp);
        DBLength = DB.length;
        byte[] mask = mgf1.generateMask(endH, DB.length);
        // 将DB和mask异或得到maskedDB
        byte[] maskedDB = DB_Xor_Mask(DB, mask);

        // 将maskedDB + endH + bc 存入EM数组
        byte[] bc = {(byte) 0xbc};
        byte[] EM = byteMerger(byteMerger(maskedDB, endH), bc);

        return EM;
    }

    public static byte[] DB_Xor_Mask(byte[] DB, byte[] mask) {
        byte[] maskedDB = new byte[DB.length];
        for (int i = 0; i < DB.length; i++) {
            maskedDB[i] = (byte) (DB[i] ^ mask[i]);
        }
        return maskedDB;
    }

    public static byte[] getSha1(byte[] plaintext) throws NoSuchAlgorithmException {

        //创建SHA1算法消息摘要对象
        MessageDigest mdTemp = MessageDigest.getInstance("SHA1");
        //使用指定的字节数组更新摘要。
        mdTemp.update(plaintext);
        //生成的哈希值的字节数组
        return mdTemp.digest();

    }

    public static byte[] byteMerger(byte[] byte_1, byte[] byte_2) {
        byte[] byte_3 = new byte[byte_1.length + byte_2.length];
        System.arraycopy(byte_1, 0, byte_3, 0, byte_1.length);
        System.arraycopy(byte_2, 0, byte_3, byte_1.length, byte_2.length);
        return byte_3;
    }
}

class MGF1 {
    private final MessageDigest digest;

    public MGF1(MessageDigest digest) {
        this.digest = digest;
    }

    private void I2OSP(int i, byte[] sp) {
        sp[0] = (byte) (i >>> 24);
        sp[1] = (byte) (i >>> 16);
        sp[2] = (byte) (i >>> 8);
        sp[3] = (byte) (i >>> 0);
    }

    public byte[] generateMask(byte[] seed, int length) {
        byte[] mask = new byte[length];
        byte[] C = new byte[4];
        int counter = 0;
        int hLen = digest.getDigestLength();
        digest.reset();
        while (counter < (length / hLen)) {
            I2OSP(counter, C);
            digest.update(seed);
            digest.update(C);
            System.arraycopy(digest.digest(), 0, mask, counter * hLen, hLen);
            counter++;
        }

        if ((counter * hLen) < length) {
            I2OSP(counter, C);
            digest.update(seed);
            digest.update(C);
            System.arraycopy(digest.digest(), 0, mask, counter * hLen, mask.length - (counter * hLen));

        }
        return mask;
    }
}


class RSA {

    //p*q
    private BigInteger n = new BigInteger("13622988371552892141295658293485149287988994768372123653173985098234908392358262565089514708984037005183301356682064242543120638035358712834620664793333600159661865746180825524641443759754549728891340046935197175075376437864429524264457212515884041269");
    private BigInteger fn = null;//欧拉函数(p-1)(q-1)
    private BigInteger e = null;//公钥
    private BigInteger d = null;//私钥

    public RSA() {                      //自动生成两个pq的值
        e = new BigInteger("13622988371552892141295658293485149287988994768372123653173985098234908392358262565089514708984037005183301356682064242543120393517437363425964026200608245406555500172152037515100390187317471681645939535001925951896712382347093603392708862166241996863");
        d = new BigInteger("10385237772035837058386824708038006183668740406382336417217836173542306846192397471144473096534916102606104173255385297005966219273382743418896342843513012193338273673837876132587741398403453748339953905606849380369691053807201401689508998063951297887");
    }

    public BigInteger getE() {
        // fn/4的下一个素数作为公钥e
        return fn.divide(BigInteger.valueOf(4)).nextProbablePrime();
    }

    // 扩展的Euclid算法，目的：算出d=e-1 mod n
    public static BigInteger[] egcd(BigInteger d1, BigInteger d2) {
        BigInteger[] ret = new BigInteger[3];
        BigInteger u1 = BigInteger.valueOf(1), u0 = BigInteger.valueOf(0);
        BigInteger v0 = BigInteger.valueOf(0), v1 = BigInteger.valueOf(1);
        if (d2.compareTo(d1) > 0) {
            BigInteger tem = d1;
            d1 = d2;
            d2 = tem;
        }
        while (d2.compareTo(BigInteger.valueOf(0)) != 0) {
            BigInteger tq = d1.divide(d2); // tq = d1 / d2
            BigInteger tu = u1;
            u1 = u0;
            u0 = tu.subtract(tq.multiply(u0)); // u0 =tu - tq * u0
            BigInteger tv = v0;
            v0 = v1;
            v1 = tv.subtract(tq.multiply(v1)); // v1 = tv - tq * v1
            BigInteger td1 = d1;
            d1 = d2;
            d2 = td1.subtract(tq.multiply(d2)); // d2 = td1 - tq * d2
            ret[0] = u1;
            ret[1] = v0;
            ret[2] = d1;
        }
        return ret;
    }

    // 加密
    public BigInteger encode(BigInteger d) {
        return d.modPow(this.e, this.n);   //快速取幂模
    }

    // 解密
    public BigInteger decode(BigInteger c) {
        return c.modPow(this.d, this.n);
    }

}
