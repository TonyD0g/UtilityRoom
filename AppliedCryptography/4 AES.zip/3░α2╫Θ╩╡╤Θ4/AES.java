

public class AES {
    static int Nb;                 //数据块字数
    static int Nk;                 //密钥字数
    static int Nr;                 //迭代轮数
    static word[][] RoundKey;      //加密轮密钥
    static word[][] InvRoundKey;   //解密轮密钥

    /**
     * 加密
     *
     * @param plaintext 4个字长度的明文
     * @param CipherKey 4、6或8个字长度的密钥
     * @return
     */
    public static word[] encrypt(word[] plaintext, word[] CipherKey) {
        Nb = 4;
        Nk = CipherKey.length;
        Nr = Nk + 6;    // 10轮
        //加密密钥扩展 ，字密钥扩展
        RoundKey = KeyExpansion(CipherKey);
        word[] ciphertext = new word[plaintext.length];
        for (int i = 0; i < plaintext.length; i++)
            ciphertext[i] = new word(plaintext[i]);

        //第0轮密钥加，异或操作   (初始变换)
        ciphertext = AddRoundKey(ciphertext, RoundKey[0]);

        //轮函数
        for (int i = 1; i < Nr + 1; i++) {
            //S盒变换  字节代替
            ciphertext = S_Box(ciphertext);
            //行移位
            ciphertext = ShiftRow(ciphertext);
            //列混合
            if (i != Nr) {
                ciphertext = mixColumns(ciphertext);
            }
            //轮密钥加
            System.out.println("第"+i+"轮密钥加:");
            ciphertext = AddRoundKey(ciphertext, RoundKey[i]);
            for (int i1 = 0; i1 < 4; i1++) {
                System.out.println(ciphertext[i1]);
            }
            System.out.println("------------------------");
        }
        return ciphertext;
    }

    /**
     * 解密
     *
     * @param ciphertext 4个字长度的密文
     * @param CipherKey  4、6或8个字长度的密钥
     * @return
     */
    // AES 的解密过程是加密过程的逆过程，轮密钥的使用顺序与加密过程完全相反，运算过程也是加密过程的逆过程
    public static word[] decrypt(word[] ciphertext, word[] CipherKey) {
        Nb = 4;
        Nk = CipherKey.length;
        Nr = Nk + 6;
        //解密密钥扩展
        InvRoundKey = InvKeyExpansion(CipherKey);
        word[] plaintext = new word[ciphertext.length];
        for (int i = 0; i < ciphertext.length; i++)
            plaintext[i] = new word(ciphertext[i]);
        //第0轮密钥加
        plaintext = AddRoundKey(plaintext, InvRoundKey[Nr]);
        //轮函数
        for (int i = Nr - 1; i >= 0; i--) {
            //S盒变换
            plaintext = INVERSE_S_Box(plaintext);
            //行移位
            plaintext = InvShiftRow(plaintext);
            //列混合
            if (i != 0) plaintext = InvMixColumn(plaintext);
            //轮密钥加
            plaintext = AddRoundKey(plaintext, InvRoundKey[i]);
        }
        return plaintext;
    }
/**************************************************************************************************/
    /**
     * S盒变换
     *
     * @param state
     * @return
     */
    // 输入的明文，查表替换，如输入的明文为19,则查第一行和第九列相交的
    static word[] S_Box(word[] state) {
        for (int i = 0; i < Nb; i++)
            for (int j = 0; j < 4; j++) {
                //乘法逆代替
                state[i].word[j] = word.inverse(state[i].word[j]);
                //仿射变换
                state[i].word[j] = AffineTransformation(state[i].word[j], 'C');
            }
        return state;
    }

    /**
     * 行移位变换
     *
     * @param state
     * @return
     */
    // 第一行不变，第二行向左移动1个字节，第三行向左移动2个字节，第四行向左移动3个字节
    static word[] ShiftRow(word[] state) {
        byte[][] b = new byte[4][Nb];
        for (int j = 0; j < Nb; j++)
            for (int i = 0; i < 4; i++)
                b[i][j] = state[j].word[i];
        for (int i = 1; i < 4; i++)
            for (int k = 0; k < i; k++) {
                byte t = b[i][0];
                for (int j = 0; j < Nb - 1; j++)
                    b[i][j] = b[i][j + 1];
                b[i][Nb - 1] = t;
            }
        for (int j = 0; j < Nb; j++)
            for (int i = 0; i < 4; i++)
                state[j].word[i] = b[i][j];
        return state;
    }

    /**
     * 列混合变换
     *
     * @param state
     * @return
     */
    // 将输入的4*4矩阵左乘一个给定的4*4矩阵
    /*
    *      02 03 01 01          p1 ... p13
    *      01 02 03 01      x   p2 ... p14
    *      01 01 02 03          p3 ... p15
    *      03 01 01 02          p4 ... p16

        得出  S0,0 =  02*p1 ^ 03*p2 ^ 01*p3 ^ 01*p4 
        (不是普通意义上的*法，具体看 列混合.png)
    *
    * */
    static word[] mixColumns(word[] state) {
        byte[] b = {(byte) 0x02, (byte) 0x01, (byte) 0x01, (byte) 0x03};
        word a = new word(b);
        for (int i = 0; i < Nb; i++)
            state[i] = word.multiply(a, state[i]);
        return state;
    }

    /**
     * 轮密钥加变换
     *
     * @param state
     * @param key
     * @return
     */
    // 和一个子密钥矩阵进行异或,一列对应一列异或
    /*
    * 如
    *   04 e0 48 28     a0 88 23 2a
    *   66 cb f8 06   ^ fa 54 a3 6c
    *   81 19 d3 26     fe 2c 39 76
    *   e5 9a 7a 4c     17 b1 39 05
    *
    * 中,04 ^ a0 = a4
    *    66 ^ fa = 9c
    *   ......
    *
    * */
    static word[] AddRoundKey(word[] state, word[] key) {
        for (int i = 0; i < Nb; i++)
            state[i] = word.add(state[i], key[i]);
        return state;
    }

    /**
     * 加密密钥扩展
     *
     * @param CipherKey
     * @return
     */
    /*
    
    1.如果i不是4的倍数，那么第i列由如下等式确定︰w[i] = W[i-4] ^ W[i-1]
    2.如果i是4的倍数，那么第i列由如下等式确定︰W[i] = W[i-4] ^ T(W[i-1])
    
    // T函数由三部分组成: 字循环,字节代换和轮常量异或

    a.字循环︰将1个字中的4个字节循环左移1个字节。即将输入字[b0, b1, b2, b3]变换成[b1,b2,b3,b0]。
    b.字节代换:对字循环的结果使用S盒进行字节代换
    c.轮常量异或:将前两步的结果同轮常量Rcon[j]进行异或，其中j表示轮数。


    */
    static word[][] KeyExpansion(word[] CipherKey) {
        word[] W = new word[Nb * (Nr + 1)];
        //密钥扩展  ,没问题
        word Temp;
        if (Nk <= 6) {
            for (int i = 0; i < Nk; i++)
                W[i] = CipherKey[i];
            for (int i = Nk; i < W.length; i++) {
                Temp = new word(W[i - 1]);
                if (i % Nk == 0) {
                    // W[i] = W[i-4] ^ T(W[i-1])

                    Temp = word.add(SubByte(Rotl(Temp)), RC(i / Nk));
                }

                W[i] = word.add(W[i - Nk], Temp);
                //System.out.println("W[" + i + "]" + W[i]);
            }
        } else {
            for (int i = 0; i < Nk; i++)
                W[i] = CipherKey[i];
            for (int i = Nk; i < W.length; i++) {
                Temp = new word(W[i - 1]);
                if (i % Nk == 0) {
                    Temp = word.add(SubByte(Rotl(Temp)), RC(i / Nk));
                } else if (i % Nk == 4) {
                    Temp = SubByte(Temp);
                }
                W[i] = word.add(W[i - Nk], Temp);
                System.out.println("W[" + i + "]" + W[i]);
            }
        }
//        for (int i1 = 0;i1<4;i1++){
//            System.out.println("W["+i1+"]"+W[i1]);
//        }

        //轮密钥选择
        word[][] RoundKey = new word[Nr + 1][Nb];
        for (int i = 0; i < Nr + 1; i++)
            for (int j = 0; j < Nb; j++) {
                RoundKey[i][j] = W[Nb * i + j];
                //System.out.println("RoundKey:" + RoundKey[i][j]);
            }

        return RoundKey;
    }

    /**
     * S盒逆变换
     *
     * @param state
     * @return
     */
    static word[] INVERSE_S_Box(word[] state) {
        for (int i = 0; i < Nb; i++)
            for (int j = 0; j < 4; j++) {
                //仿射变换
                state[i].word[j] = AffineTransformation(state[i].word[j], 'D');
                //乘法逆代替
                state[i].word[j] = word.inverse(state[i].word[j]);
            }
        return state;
    }

    /**
     * 行移位逆变换
     *
     * @param state
     * @return
     */
    static word[] InvShiftRow(word[] state) {
        byte[][] b = new byte[4][Nb];
        for (int j = 0; j < Nb; j++)
            for (int i = 0; i < 4; i++)
                b[i][j] = state[j].word[i];
        for (int i = 1; i < 4; i++)
            for (int k = 0; k < Nb - i; k++) {
                byte t = b[i][0];
                for (int j = 0; j < Nb - 1; j++)
                    b[i][j] = b[i][j + 1];
                b[i][Nb - 1] = t;
            }
        for (int j = 0; j < Nb; j++)
            for (int i = 0; i < 4; i++)
                state[j].word[i] = b[i][j];
        return state;
    }

    /**
     * 列混合逆变换
     *
     * @param state
     * @return
     */
    static word[] InvMixColumn(word[] state) {
        byte[] b = {(byte) 0x0E, (byte) 0x09, (byte) 0x0D, (byte) 0x0B};
        word a = new word(b);
        for (int i = 0; i < Nb; i++)
            state[i] = word.multiply(a, state[i]);
        return state;
    }

    /**
     * 解密密钥扩展
     *
     * @param CipherKey
     * @return
     */
    static word[][] InvKeyExpansion(word[] CipherKey) {
        word[][] InvRoundKey = KeyExpansion(CipherKey);
        for (int i = 1; i < Nr; i++)
            InvRoundKey[i] = InvMixColumn(InvRoundKey[i]);
        return InvRoundKey;
    }

    /**************************************************************************************************/
    static word SubByte(word a) {
        word w = new word(a);
        for (int i = 0; i < 4; i++) {
            //乘法逆代替
            w.word[i] = word.inverse(w.word[i]);
            //仿射变换
            w.word[i] = AffineTransformation(w.word[i], 'C');
        }
        return w;
    }

    static word Rotl(word a) {
        word w = new word(a);
        byte b = w.word[0];
        for (int i = 0; i < 3; i++)
            w.word[i] = w.word[i + 1];
        w.word[3] = b;
        return w;
    }

    static word RC(int n) {
        word RC = new word(new byte[4]);
        byte RC = 1;
        for (int i = 1; i < n; i++)
            RC = word.xtime(RC);
        RC.word[0] = RC;
        return RC;
    }

    /**
     * 仿射变换
     *
     * @param b
     * @param sign C：加密  D：解密
     * @return
     */
    static byte AffineTransformation(byte b, char sign) {
        byte[] x = Integer.toBinaryString((b & 0xff) + 0x100).substring(1).getBytes();
        for (int i = 0; i < x.length; i++) x[i] -= '0';
        if (sign == 'C') {
            byte[] x_ = new byte[8];
            byte b_ = 0;
            for (int i = 0; i < 8; i++) {
                x_[i] = (byte) (x[i] ^ x[(i + 1) % 8] ^ x[(i + 2) % 8] ^ x[(i + 3) % 8] ^ x[(i + 4) % 8]);
                b_ += x_[i] * Math.pow(2, 7 - i);
            }
            return (byte) (b_ ^ 0x63);
        } else {
            byte[] x_ = new byte[8];
            byte b_ = 0;
            for (int i = 0; i < 8; i++) {
                x_[i] = (byte) (x[(i + 1) % 8] ^ x[(i + 3) % 8] ^ x[(i + 6) % 8]);
                b_ += x_[i] * Math.pow(2, 7 - i);
            }
            return (byte) (b_ ^ 0x05);
        }
    }
}