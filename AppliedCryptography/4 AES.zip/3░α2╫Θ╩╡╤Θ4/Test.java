


public class Test {
    public static void main(String[] args) {
        byte[] plain = {
                (byte) 0x01, (byte) 0x23, (byte) 0x45, (byte) 0x67,
                (byte) 0x89, (byte) 0xab, (byte) 0xcd, (byte) 0xef,
                (byte) 0xfe, (byte) 0xdc, (byte) 0xba, (byte) 0x98,
                (byte) 0x76, (byte) 0x54, (byte) 0x32, (byte) 0x10
        };
        byte[] key_state = {
                (byte) 0xfe, (byte) 0xdc, (byte) 0xba, (byte) 0x98,
                (byte) 0x76, (byte) 0x54, (byte) 0x32, (byte) 0x10,
                (byte) 0x01, (byte) 0x23, (byte) 0x45, (byte) 0x67,
                (byte) 0x89, (byte) 0xab, (byte) 0xcd, (byte) 0xef
        };
        word[] m_state = toWordArr(plain);
        System.out.println("明文：" + wordArrStr(m_state));
        word[] CipherKey = toWordArr(key_state);
        System.out.println("密钥：" + wordArrStr(CipherKey));
        word[] c_state = AES.encrypt(m_state, CipherKey);
        System.out.println("密文：" + handleOut(wordArrStr(c_state)));
        word[] newPlainText = AES.decrypt(c_state, CipherKey);
        System.out.println("明文：" + wordArrStr(newPlainText));
    }

    // 处理输出
    static StringBuffer handleOut(String str) {
        StringBuffer stringBuffer = new StringBuffer(str);
        StringBuffer outcome = new StringBuffer();
        int x = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 32; j = j +8) {
                //System.out.println("test:" + stringBuffer.charAt(j + x) + stringBuffer.charAt(j + 1 + x));
                outcome.append(stringBuffer.charAt(j + x));
                outcome.append(stringBuffer.charAt(j + 1 + x));
            }
            x = x + 2;
        }
        return outcome;
    }

    static word[] toWordArr(byte[] b) {
        int len = b.length / 4;
        if (b.length % 4 != 0) len++;
        word[] w = new word[len];
        for (int i = 0; i < len; i++) {
            byte[] c = new byte[4];
            if (i * 4 < b.length) {
                for (int j = 0; j < 4; j++)
                    c[j] = b[i * 4 + j];
            }
            w[i] = new word(c);
        }
        return w;
    }

    static String wordArrStr(word[] w) {
        String str = "";
        for (word word : w)
            str += word;
        return str;
    }
}