package JavaShell;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {

        System.out.println("请输入明文");
        Scanner in = new Scanner(System.in);
        String plaintext = in.nextLine();
        System.out.println("请输入密钥");
        Scanner sc1 = new Scanner(System.in);
        String key = sc1.nextLine();

        StringBuilder str1 = encrypt(plaintext, key);

        decrypt(String.valueOf(str1), key);


    }

    public static StringBuilder encrypt(String plaintext, String key) {
        System.out.println("加密完成");
        //放入一维数组
        char arr[] = plaintext.toCharArray();
        for (int i = 0; i < key.length(); i++) {
            char a = key.charAt(i);
        }
        int row = plaintext.length() / key.length() + 1;
        char arr1[][] = new char[row][key.length()];
        //一维数组的位置
        int k = 0;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < key.length(); j++) {
                if (k == plaintext.length()) {
                    break;
                }
                arr1[i][j] = arr[k];
                k++;
                // System.out.println(arr1[i][j]);
            }
        }
        //key转int b数组
        int b[] = new int[key.length()];
        int c[] = new int[key.length()];
        for (int i = 0; i < key.length(); i++) {
            int a = key.charAt(i) - '0';
            b[i] = a;
            // System.out.print(b[i]);
        }
        for (int i = 0; i < b.length; i++) {
            int index = getIndex(b, i + 1);
            c[i] = index;
            //  System.out.println("index" + index);
        }
        //c为排序好的数组代表每个数子的位置
        System.out.println("加密结果如下：");

        StringBuilder str1 = new StringBuilder();

        for (int i = 0; i < key.length(); i++) {
            for (int j = 0; j < row; j++) {
                if ((c[i] + j * key.length()) >= plaintext.length()) {
                    break;
                }
                str1.append(arr1[j][c[i]]);
            }
        }
        System.out.println(str1);

        return str1;
    }

    public static StringBuilder decrypt(String ciphertext, String key) {
        int row=ciphertext.length()/key.length();

        int surplus=ciphertext.length()%key.length();
        
        char [] sheng=new char[surplus];
        int b[] = new int[key.length()];
        for(int i=0;i<key.length();i++) {
            int a=key.charAt(i)-'0';
            b[i]=a;

        }

        char arr[]=ciphertext.toCharArray();
        if(surplus!=0) {
            for(int i=1;i<=surplus;i++) {
                sheng[i-1]=arr[b[i-1]*row];

                arr[b[i-1]*row]=35;

            }
        }
        

        char arr1[][]=new char[row][key.length()];

        int k=0;
        for(int i=0;i<key.length();i++) {
            for(int j=0;j<row;j++) {
                if(arr[k]==35)
                    k++;
                arr1[j][i]=arr[k];
                k++;
            }
        }
        StringBuilder str1 = new StringBuilder();
        
        System.out.println("解密结果如下：");
        for(int j=0;j<row;j++) {
            for(int i=0;i<key.length();i++) {
                str1.append(arr1[j][b[i]-1]);
            }
        }
        for(int i=0;i<surplus;i++) {
            str1.append(sheng[i]);
        }
        System.out.println(str1+"\n解密完成");

        return str1;

    }
    public static int getIndex(int[] arr, int value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == value) {
                return i;
            }
        }
        return -1;
    }

}

