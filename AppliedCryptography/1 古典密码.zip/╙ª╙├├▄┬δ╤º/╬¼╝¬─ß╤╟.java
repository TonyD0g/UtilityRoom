package JavaShell;

// 维吉尼亚密码

public class Test {

    public static void main(String[] args) throws Exception {

        String plaintext = "happy";
        String key = "dog";
        System.out.println("要加密的文本：" + plaintext);
        String ciphertext = encrypt(plaintext, key);
        System.out.println("加密后的文本：" + ciphertext);
        System.out.println("解密后的文本：" + decrypt(ciphertext, key));
    }


    public static String encrypt(String message, String key) {

        String result = "";

        for (int i = 0, j = 0; i < message.length(); i++) {
            char c = message.charAt(i);
            // 是否是字母
            if (Character.isLetter(c)) {
                // 是否是大写
                if (Character.isUpperCase(c)) {
                    // 密文字符 = (明文字符+对应位置密钥字符)mod 26
                    result = result + (char) ((c + key.toUpperCase().charAt(j) - 2 * 'A') % 26 + 'A');

                } else {
                    int middle = c + key.toLowerCase().charAt(j);
                    int middle1 = (middle - 2 * 'a');
                    int middle3 =  middle1 % 26;
                    result = result + (char) (middle3 + 'a');
                }
            } else {
                result = result + c;
            }
            j = (j + 1) % key.length();
        }
        return result;
    }

    public static String decrypt(String message, String key) {
        String result = "";

        for (int i = 0, j = 0; i < message.length(); i++) {

            char c = message.charAt(i);
            if (Character.isLetter(c)) {
                if (Character.isUpperCase(c)) {
                    // 明文字符 = (密文字符 - 对应位置密钥字符) mod 26
                    result =result + ((char) ('Z' - (25 - (c - key.toUpperCase().charAt(j))) % 26));

                } else {
                    result =result + ((char) ('z' - (25 - (c - key.toLowerCase().charAt(j))) % 26));
                }
            } else {
                result += c;
            }

            j = ++j % key.length();
        }
        return result;
    }


}
