package JavaShell;

import java.util.Locale;
import java.util.Scanner;

// 单表替换密码
// betterlatethannever

public class Test {
    // Ascii 码最小为97时，才是数字
    public static final int keys = 96;
    public static final int[] key = {10,16,22,5,25,23,4,21,12,20,8,1,15,18,7,19,26,13,9,2,24,3,17,6,14,11};
    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);
        System.out.println("请输入要加密的明文：");
        String plaintext = sc.nextLine();
        System.out.println("加密后的结果："+ encrypt(plaintext));
        System.out.println("解密后的结果："+ decrypt(plaintext));
    }

    public static int charToInt(char c) {
        return (int) c - keys;
    }

    public static char intToChar(int v) {
        return (char) (v + keys);
    }

    public static String encrypt(String str) {
        str = str.toLowerCase(Locale.ENGLISH);
        char[] chars = str.toCharArray();
        char[] encodes = new char[chars.length];
        int charValue;
        for (int i = 0; i < chars.length; i++) {
            charValue = charToInt(chars[i]);
            if (charValue < 0 || charValue > 25) {
                encodes[i] = chars[i];
            } else {
                encodes[i] = intToChar(key[charValue-1]);
            }
        }
        return new String(encodes);
    }

    public static int charToInt1(char c) {
        return (int) c + keys;
    }

    public static String decrypt(String str) {
        str = str.toLowerCase(Locale.ENGLISH);
        char[] chars = str.toCharArray();
        char[] encodes = new char[chars.length];
        int charValue;
        for (int i = 0; i < chars.length; i++) {
            charValue = charToInt1(chars[i]);
            if (charValue < 0 || charValue > 25) {
                encodes[i] = chars[i];
            } else {
                encodes[i] = intToChar(key[charValue-1]);
            }
        }
        return new String(encodes);
    }

}



